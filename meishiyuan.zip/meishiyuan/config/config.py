# -*- coding: utf-8 -*-
# @Time : 2020/12/20 15:00
# @Author : fcj11
# @Email : yangfit@126.com
# @File : cofig.py
# @Project : meishiyuan
import os

BASE_PATH = os.path.dirname(__file__).strip('config')
REPORT_PATH = os.path.join(BASE_PATH, 'report')
CASE_PATH = os.path.join(BASE_PATH, 'case')
DATA_PATH = os.path.join(BASE_PATH, 'data')
